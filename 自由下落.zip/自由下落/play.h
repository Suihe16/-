#ifndef PLAY_H
#define PLAY_H

#include <stdio.h>
#include <string.h>
#include <easyx.h>
#include <Mmsystem.h>
#include <iostream>
#include <vector>
#include <ctime>
#include <fstream>
#include <sstream>
#include <windows.h>
#include <stdlib.h>
#include<thread>
#include <algorithm>
#pragma comment(lib,"winmm.lib")

int puzzle();
int log();
extern int login;

struct Rect
{
    int x;
    int y;
    int w;
    int h;
};

struct User
{
    uint32_t id;
    char userName[32];
    char password[32];
    int shortTime;
};
extern std::vector<User*> users;
extern User* currentUser;

#endif
